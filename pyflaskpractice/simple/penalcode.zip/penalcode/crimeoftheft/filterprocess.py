# coding=utf8
'''
根据盗窃量刑流程, 生成情节判定字典
'''
import codecs
import chardet
import re
str1 = u'填写项目为.{,10}项下选择'
str2 = u'^\(\d\).{,20},基准刑乘以.{,5}到基准刑乘以.{,5}'
str3 = u'^基准刑乘以.{,5}得到基准刑乘以.{,5}'
partternprojectName = re.compile(str1)
partternprojectValue = re.compile(str2)
partternprojectCoeff = re.compile(str3)



with codecs.open('process.txt', 'r', encoding='utf8') as f:



    projectName = 0
    for line in f.readlines():
        # line = line.trip()
        print line,'*'*3,
        res = partternprojectName.findall(line)
        for r in res:
            print r,'*'*3,
        res = partternprojectValue.findall(line)
        for r in res:
            print r,'*'*3,

        res = partternprojectCoeff.findall(line)
        for r in res:
            print r,'*'*3,

        print ' '
# coding=utf8

'''
unit test file
'''

import config_blogsys
import manage
import config_blogsys
import manage